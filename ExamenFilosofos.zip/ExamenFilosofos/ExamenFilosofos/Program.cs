﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ExamenFilosofos
{
    class Program
    {
        static void Main(string[] args)
        {
            //Asignacion de cantidad de Filosofos
            const int numFilosof = 5;

            //Uso de la clase Filosofo como variable
            Filosofo[] filosof = new Filosofo[5];
            filosof[0] = new Filosofo(0, 0, numFilosof - 1, 0);

            //Arreglo para recorrer el orden de los filosofos con los palillos
            for (int i = 1; i < numFilosof; i++)
            {
                filosof[i] = new Filosofo(i, i - 1, i, 0);
            }

            //Hilos
            var H1 = new Thread(new ParameterizedThreadStart(filosof[0].comer));
            var H2 = new Thread(new ParameterizedThreadStart(filosof[1].comer));
            var H3 = new Thread(new ParameterizedThreadStart(filosof[2].comer));
            var H4 = new Thread(new ParameterizedThreadStart(filosof[3].comer));
            var H5 = new Thread(new ParameterizedThreadStart(filosof[4].comer));
            H1.Start(filosof[0]);
            H2.Start(filosof[1]);
            H3.Start(filosof[2]);
            H4.Start(filosof[3]);
            H5.Start(filosof[4]);

            Console.ReadKey();
        }

        class Filosofo
        {
            //Declaracion de Variables
            int index;
            int tandpetareVan;
            int tandpetareHog;
            int cmelman;

            //Llamado de variables para su uso
            public Filosofo(int indice, int palilloIzq, int palilloDrc, int cmelmansueco)
            {
                this.index = indice;
                this.tandpetareVan = palilloIzq;
                this.tandpetareHog = palilloDrc;
                this.cmelman = cmelmansueco;
            }

            //Metodo para el proceso de cada Filosofo
            public void comer(object param)
            {

                Object[] objetos = new Object[5];

                //Metodo FOR para alternar el orden de los Filoso
                for (int i = 0; i < objetos.Length; i++)
                {
                    objetos[i] = new Object();
                }
                Filosofo filo = (Filosofo)param;

                //Metodo FOR para hacer que cada Filosofo coma 5 veces
                for (int i = 0; i < 5; i++){
                    //Metodo IF para asignar los palillos a cada filosofo, sea derecho o izquierdo
                    if (Monitor.TryEnter(objetos[filo.tandpetareVan], 1000)){
                        try{
                            lock (Console.Out)
                            {
                                Console.ForegroundColor = ConsoleColor.Cyan;
                                Console.WriteLine("El Filosofo {0} toma el palillo Izquierdo", index);
                            }
                            


                            if (Monitor.TryEnter(objetos[filo.tandpetareHog], 1000))
                            {
                                try{
                                    Console.WriteLine("El Filosofo {0} toma el palillo Derecho", index);
                                    Console.WriteLine("El Filosofo {0} esta comiendo", index);
                                    cmelman++;
                                    Console.WriteLine("El Filosofo {0} ha comido " + cmelman + " veces", index);
                                }
                                finally
                                {
                                    Monitor.Exit(objetos[filo.tandpetareHog]);
                                    Console.WriteLine("El Filosofo {0} dejo el palillo Izquierdo", index);
                                }
                            }
                            else
                            {
                                Console.WriteLine("El Filosofo {0} tiene hambre", index);
                            }
                        }
                        finally{
                            Monitor.Exit(objetos[filo.tandpetareVan]);
                            Console.WriteLine("El Filosofo {0} dejo el palillo Derecho", index);
                        }
                    }
                    else{
                        Console.WriteLine("El Filosofo {0} tiene hambre", index);
                    }
                }
            }
        }
    }
}